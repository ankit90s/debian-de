### This is the official repository for python plugins.

This repository is shipped with albert. If you want to have bleeding edge plugins or share your work clone the repository. Check the [docs on Python plugins](https://github.com/albertlauncher/plugins/blob/master/python/README.md). To install the plugins in user space type the following in your terminal:

```shell
git clone https://github.com/albertlauncher/python.git ~/.local/share/albert/python/plugins
```
